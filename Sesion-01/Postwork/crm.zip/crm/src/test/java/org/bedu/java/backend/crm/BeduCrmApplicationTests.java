package org.bedu.java.backend.crm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BeduCrmApplicationTests {

    @Test
    void contextLoads() {
    }

}
